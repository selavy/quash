#ifndef _ENVIRONMENT_
#define _ENVIRONMENT_

#include <stdlib.h>

char ** get_environment();
void set_environment(char ** env);

#endif
